package org.packt.Spring.chapter2.callbacks;

/**
 * 
 * @author RaviKantSoni
 * 
 */
public interface EmployeeService {

	public Long generateEployeeID();

}

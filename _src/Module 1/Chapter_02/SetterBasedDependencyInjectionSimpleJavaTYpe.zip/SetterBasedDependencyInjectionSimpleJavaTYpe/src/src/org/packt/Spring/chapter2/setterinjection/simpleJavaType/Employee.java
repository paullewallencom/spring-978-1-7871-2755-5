package src.org.packt.Spring.chapter2.setterinjection.simpleJavaType;

public class Employee {

	String employeeName;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

}

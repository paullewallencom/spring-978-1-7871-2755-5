package src.org.packt.Spring.chapter2.setterinjection.simpleJavaType;

public class EmployeeService {

	private Employee employee;

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
}

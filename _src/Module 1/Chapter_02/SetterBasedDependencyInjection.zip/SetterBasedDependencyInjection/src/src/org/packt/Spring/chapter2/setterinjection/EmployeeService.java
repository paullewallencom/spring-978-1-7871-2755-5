package src.org.packt.Spring.chapter2.setterinjection;

public class EmployeeService {

	private Employee employee;

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
}
